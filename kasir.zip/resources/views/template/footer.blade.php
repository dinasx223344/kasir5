<footer>
  <div class="pull-right">
    JCafe copyright 2024 - <a href="https://colorlib.com">Colorlib</a>
  </div>
  <div class="clearfix"></div>
</footer>
<!-- /footer content -->


<!-- jQuery -->
<script src="{{ asset('template')}}/vendors/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="{{ asset('template')}}/vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<!-- FastClick -->
<script src="{{ asset('template')}}/vendors/fastclick/lib/fastclick.js"></script>
<!-- NProgress -->
<script src="{{ asset('template')}}/vendors/nprogress/nprogress.js"></script>
<!-- Chart.js -->
<script src="{{ asset('template')}}/vendors/Chart.js/dist/Chart.min.js"></script>
<!-- gauge.js -->
<script src="{{ asset('template')}}/vendors/gauge.js/dist/gauge.min.js"></script>
<!-- bootstrap-progressbar -->
<script src="{{ asset('template')}}/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
<!-- iCheck -->
<script src="{{ asset('template')}}/vendors/iCheck/icheck.min.js"></script>
<!-- Skycons -->
<script src="{{ asset('template')}}/vendors/skycons/skycons.js"></script>
<!-- Flot -->
<script src="{{ asset('template')}}/vendors/Flot/jquery.flot.js"></script>
<script src="{{ asset('template')}}/vendors/Flot/jquery.flot.pie.js"></script>
<script src="{{ asset('template')}}/vendors/Flot/jquery.flot.time.js"></script>
<script src="{{ asset('template')}}/vendors/Flot/jquery.flot.stack.js"></script>
<script src="{{ asset('template')}}/vendors/Flot/jquery.flot.resize.js"></script>
<!-- Flot plugins -->
<script src="{{ asset('template')}}/vendors/flot.orderbars/js/jquery.flot.orderBars.js"></script>
<script src="{{ asset('template')}}/vendors/flot-spline/js/jquery.flot.spline.min.js"></script>
<script src="{{ asset('template')}}/vendors/flot.curvedlines/curvedLines.js"></script>
<!-- DateJS -->
<script src="{{ asset('template')}}/vendors/DateJS/build/date.js"></script>
<!-- JQVMap -->
<script src="{{ asset('template')}}/vendors/jqvmap/dist/jquery.vmap.js"></script>
<script src="{{ asset('template')}}/vendors/jqvmap/dist/maps/jquery.vmap.world.js"></script>
<script src="{{ asset('template')}}/vendors/jqvmap/examples/js/jquery.vmap.sampledata.js"></script>
<!-- bootstrap-daterangepicker -->
<script src="{{ asset('template')}}/vendors/moment/min/moment.min.js"></script>
<script src="{{ asset('template')}}/vendors/bootstrap-daterangepicker/daterangepicker.js"></script>

<!-- Custom Theme Scripts -->
<script src="{{ asset('template')}}/build/js/custom.min.js"></script>
<script src="{{ asset('sweetalert2')}}/sweetalert2.min.js"></script>
<script src="https://cdn.datatables.net/2.0.1/js/dataTables.min.js"></script>




@stack('script')

</body>

</html>