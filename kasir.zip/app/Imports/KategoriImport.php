<?php

namespace App\Imports;

use App\Models\kategori;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class KategoriImport implements ToCollection, WithHeadingRow
{
    public function collection(Collection $rows)
    {
        foreach ($rows as $row) {
            kategori::create([
                'nama_kategori' => $row['nama_kategori'],
            ]);
        }
    }
}
