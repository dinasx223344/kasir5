<div class="x_content">
    <div class="table-responsive">
        <table class="table table-compact table stripped" id="tbl-jenis">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Menu</th>
                    <th>Jumlah</th>
                    <th>Tools</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $stok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i = !isset ($i) ? ($i = 1) : ++$i); ?></td>
                    <td><?php echo e($p->menu->nama_menu); ?></td>
                    <td><?php echo e($p->jumlah); ?></td>
                    <td>
                        <button class="btn text-warning" data-toggle="modal" data-target="#modalFormstok" data-mode="edit" data-id="<?php echo e($p->id); ?>" data-menu_id="<?php echo e($p->menu_id); ?>" data-jumlah="<?php echo e($p->jumlah); ?>">
                            <i class="fas fa-edit"></i>
                        </button>
                        <form method="post" action="<?php echo e(route('stok.destroy', $p->id)); ?>" style="display: inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="button" class="btn text-danger delete-data" data-id_menu="<?php echo e($p->id_menu); ?>">
                                <i class="fas fa-trash"></i>
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div><?php /**PATH C:\xampp\htdocs\kasir\resources\views/stok/table.blade.php ENDPATH**/ ?>