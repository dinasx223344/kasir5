<div class="x_content">
    <div class="table-responsive">
        <table class="table table-compact table stripped" id="tbl-pelanggan">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>No Telpon</th>
                    <th>Alamat</th>
                    <th>Tools</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $pelanggan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i = !isset ($i) ? ($i = 1) : ++$i); ?></td>
                    <td><?php echo e($p->nama); ?></td>
                    <td><?php echo e($p->email); ?></td>
                    <td><?php echo e($p->no_telp); ?></td>
                    <td><?php echo e($p->alamat); ?></td>
                    <td>
                        <button class="btn text-warning" data-toggle="modal" data-target="#modalFormpelanggan" data-mode="edit" data-id="<?php echo e($p->id); ?>" data-nama="<?php echo e($p->nama); ?>" data-email="<?php echo e($p->email); ?>" data-no_telp="<?php echo e($p->no_telp); ?>" data-alamat="<?php echo e($p->alamat); ?>">
                            <i class="fas fa-edit"></i>
                        </button>
                        <form method="post" action="<?php echo e(route('pelanggan.destroy', $p->id)); ?>" style="display: inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="button" class="btn text-danger delete-data" data-nama="<?php echo e($p->nama); ?>">
                                <i class="fas fa-trash"></i>
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div><?php /**PATH C:\xampp\htdocs\kasir\resources\views/pelanggan/table.blade.php ENDPATH**/ ?>