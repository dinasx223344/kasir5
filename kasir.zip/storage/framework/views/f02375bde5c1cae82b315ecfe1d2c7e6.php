<head>
    <style>
        @media print {

            /* Sembunyikan elemen yang tidak perlu dicetak */
            body * {
                visibility: hidden;
            }

            /* Hanya menampilkan bagian yang ingin dicetak */
            #printableArea,
            #printableArea * {
                visibility: visible;
            }

            /* Stil khusus untuk bagian yang ingin dicetak */
            #printableArea {
                position: absolute;
                left: 0;
                top: 0;
            }
        }
    </style>
</head>

<body>
    <div id="printableArea">
        <!-- Konten yang ingin dicetak -->
        <h2>C A F E</h2>
        <h5>Jl. Siliwangi N0. 61 Cianjur</h5>
        <hr>

        <?php if(isset($transaksi)): ?>
        <h5>No. Faktur : <?php echo e($transaksi->id); ?> </h5>
        <h5> <?php echo e($transaksi->tanggal); ?> </h5>

        <table>
            <thead>
                <tr>
                    <th>Qty</th>
                    <th>Item</th>
                    <th>Harga</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $transaksi->detailTransaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td contenteditable="true"><?php echo e($item->jumlah); ?></td>
                    <td><?php echo e($item->menu->nama_menu); ?></td>
                    <td><?php echo e(number_format($item->menu->harga, 0, ',', '.')); ?></td>
                    <td><?php echo e(number_format($item->subtotal, 0, ',', '.')); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="3">Total</td>
                    <td><?php echo e(number_format($transaksi->total_harga, 0, ',', '.')); ?></td>
                </tr>
            </tfoot>
        </table>
        <?php else: ?>
        <p>No Transaction Found.</p>
        <?php endif; ?>
    </div>

    <!-- Tombol untuk mencetak -->
    <button onclick="printPage()">Cetak</button>

    <!-- Skrip untuk mencetak -->
    <script>
        function printPage() {
            window.print();
        }
    </script>
</body><?php /**PATH C:\xampp\htdocs\kasir\resources\views/faktur/index.blade.php ENDPATH**/ ?>