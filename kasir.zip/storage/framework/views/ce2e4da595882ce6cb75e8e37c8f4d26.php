<div class="x_content">
    <div class="table-responsive">
        <table class="table table-compact table stripped" id="tbl-jenis">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Menu</th>
                    <th>Jenis</th>
                    <th>Harga</th>
                    <th>Image</th>
                    <th>Deskripsi</th>
                    <th>Tools</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i = !isset ($i) ? ($i = 1) : ++$i); ?></td>
                    <td><?php echo e($p->nama_menu); ?></td>
                    <td><?php echo e($p->jenis->nama_jenis); ?></td>
                    <td><?php echo e($p->harga); ?></td>
                    <td><img width="70px" src="<?php echo e(asset('images')); ?>/<?php echo e($p->image); ?>" alt="" srcset=""></td>
                    <td><?php echo e($p->deskripsi); ?></td>
                    <td>
                        <button class="btn text-warning" data-toggle="modal" data-target="#modalFormmenu" data-mode="edit" data-id="<?php echo e($p->id); ?>" data-nama_menu="<?php echo e($p->nama_menu); ?>" data-jenis_id="<?php echo e($p->jenis_id); ?>" data-harga="<?php echo e($p->harga); ?>" data-image="<?php echo e($p->image); ?>" data-deskripsi="<?php echo e($p->deskripsi); ?>">
                            <i class="fas fa-edit"></i>
                        </button>
                        <form method="post" action="<?php echo e(route('menu.destroy', $p->id)); ?>" style="display: inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="button" class="btn text-danger delete-data" data-nama_menu="<?php echo e($p->nama_menu); ?>">
                                <i class="fas fa-trash"></i>
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div><?php /**PATH C:\xampp\htdocs\kasir\resources\views/menu/table.blade.php ENDPATH**/ ?>