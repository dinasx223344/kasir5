<div class="x_content">
    <div class="table-responsive">
        <table class="table table-compact table stripped" id="tbl-kategori">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama kategori</th>
                    <th>Tools</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i = !isset ($i) ? ($i = 1) : ++$i); ?></td>
                    <td><?php echo e($p->nama_kategori); ?></td>
                    <td>
                        <button class="btn text-warning" data-toggle="modal" data-target="#modalFormkategori" data-mode="edit" data-id="<?php echo e($p->id); ?>" data-nama_kategori="<?php echo e($p->nama_kategori); ?>">
                            <i class=" fas fa-edit"></i>
                        </button>
                        <form method="post" action="<?php echo e(route('kategori.destroy', $p->id)); ?>" style="display: inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="button" class="btn text-danger delete-data" data-nama_kategori=""="<?php echo e($p->nama_kategori); ?>">
                                <i class="fas fa-trash"></i>
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div><?php /**PATH C:\xampp\htdocs\kasir\resources\views/kategori/table.blade.php ENDPATH**/ ?>