<div class="x_content">
    <div class="table-responsive">
        <table class="table table-compact table stripped" id="tbl-jenis">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Jenis</th>
                    <th>Tools</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $jenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i = !isset ($i) ? ($i = 1) : ++$i); ?></td>
                    <td><?php echo e($p->nama_jenis); ?></td>
                    <td>
                        <button class="btn text-warning" data-toggle="modal" data-target="#modalFormjenis" data-mode="edit" data-id="<?php echo e($p->id); ?>" data-nama_jenis="<?php echo e($p->nama_jenis); ?>" >
                            <i class=" fas fa-edit"></i>
                        </button>
                        <form method="post" action="<?php echo e(route('jenis.destroy', $p->id)); ?>" style="display: inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="button" class="btn text-danger delete-data" data-nama="<?php echo e($p->nama_jenis); ?>">
                                <i class="fas fa-trash"></i>
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div><?php /**PATH C:\xampp\htdocs\kasir\resources\views/jenis/table.blade.php ENDPATH**/ ?>